// main.js - Initialize any JavaScript functionality here
document.addEventListener("DOMContentLoaded", () => {
    console.log("Fashion Hub website loaded successfully.");
  });
  